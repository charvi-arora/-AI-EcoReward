# Archived EcoScan screenshots

These PNGs capture the original Vietnamese EcoScan interface. They are
reference images. The English AI EcoReward demo opens at
http://127.0.0.1:8000/.
