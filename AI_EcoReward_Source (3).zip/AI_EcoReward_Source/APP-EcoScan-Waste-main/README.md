# AI EcoReward backend

AI EcoReward uses FastAPI and YOLO11n to detect supported objects and provide
disposal guidance. SQLite stores profiles, scan history, points and proof
review results. The browser demo opens at http://127.0.0.1:8000/ and the
interactive API documentation opens at http://127.0.0.1:8000/docs.

See [PROTOTYPE.md](PROTOTYPE.md) for Windows setup and the demonstration steps.
The Expo mobile project is in [mobile-app](../mobile-app).

## EcoScan reference implementation

This folder also contains the original EcoScan ResNet50 classifier and its
web template. The reference classifier accepts a multipart image under the
`file` field at `POST /api/classify` and returns the class, display name,
confidence percentage and description. The reference chatbot accepts
`{"message": "How do I sort organic waste?"}` at `POST /api/chat` and
streams plain text in English when configured with a Groq API key.

The reference model details and dataset are in [MODEL_DOWNLOAD.md](MODEL_DOWNLOAD.md).
The images in [screenshots](screenshots) are archived captures from the
original Vietnamese EcoScan interface. They are separate from the live
AI EcoReward application.

Original EcoScan project by [franceto (Anh Phap To)](https://github.com/franceto/ecoscan-app).
