from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse
from backend.utils.model_loader import classifier
from backend.utils.image_processor import process_image
from backend.config import CLASS_DESCRIPTIONS, CLASS_NAMES

router = APIRouter()

# The web client displays confidence as a percentage.
CONFIDENCE_THRESHOLD = 58.0

@router.post("/classify")
async def classify_image(file: UploadFile = File(...)):
    if classifier.model is None:
        return JSONResponse({"error": "The classification model is unavailable."}, status_code=503)

    try:
        contents = await file.read()
        image_tensor = process_image(contents)
        
        predicted_class, probability = classifier.predict(image_tensor)
        confidence = round(probability * 100, 2)
        
        if confidence < CONFIDENCE_THRESHOLD:
            return JSONResponse({
                "type": "not_waste",
                "error": "The model could not classify this photo confidently.",
                "confidence": confidence
            }, status_code=422)
        
        return JSONResponse({
            "class": predicted_class,
            "class_name": CLASS_NAMES.get(predicted_class, predicted_class),
            "confidence": confidence,
            "description": CLASS_DESCRIPTIONS.get(predicted_class, "")
        })
        
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
