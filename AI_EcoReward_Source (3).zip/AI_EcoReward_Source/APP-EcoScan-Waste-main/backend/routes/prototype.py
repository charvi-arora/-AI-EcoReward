"""AI EcoReward's scan, proof, and progress API."""
import json
import logging
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
from io import BytesIO
from secrets import token_urlsafe
from uuid import uuid4

from fastapi import APIRouter, Depends, File, Header, HTTPException, UploadFile
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel, Field

from backend.routes.rewards import BASE_POINTS, PROOF_BONUS
from backend.utils import detector, proof_verifier
from backend.utils.prototype_store import database, profile_view, scan_view

router = APIRouter(prefix="/api/v1", tags=["EcoReward prototype"])
logger = logging.getLogger(__name__)
MAX_UPLOAD = 5 * 1024 * 1024
LOCAL_TZ = timezone(timedelta(hours=5, minutes=30))

GUIDANCE = {
    "bottle": "Check the bottle material and use the matching local recycling stream.",
    "plastic": "Empty the item and follow your local plastic recycling rules.",
    "glass": "Keep glass separate and follow your local glass collection rules.",
    "metal": "Empty the item and follow your local metal recycling rules.",
    "paper": "Keep clean paper and cardboard dry for recycling.",
    "organic": "Use the local wet-waste collection or an appropriate compost system.",
    "battery": "Use a designated battery collection point.",
    "e_waste": "Use an authorized e-waste collection point.",
}


class ProfileRequest(BaseModel):
    name: str = Field(min_length=1, max_length=50)


def now():
    return datetime.now(LOCAL_TZ)


def profile_for_token(authorization: str = Header(default="")):
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(401, "A profile bearer token is required.")
    digest = sha256(token.encode()).hexdigest()
    with database() as db:
        row = db.execute("SELECT id FROM profiles WHERE token_hash = ?", (digest,)).fetchone()
    if row is None:
        raise HTTPException(401, "Invalid profile token.")
    return row["id"]


def get_profile(db, profile_id):
    return db.execute("SELECT * FROM profiles WHERE id = ?", (profile_id,)).fetchone()


def get_scan(db, scan_id, profile_id):
    row = db.execute(
        "SELECT * FROM scans WHERE id = ? AND profile_id = ?", (scan_id, profile_id)
    ).fetchone()
    if row is None:
        raise HTTPException(404, "Scan not found.")
    return row


def read_image(file):
    content = file.file.read(MAX_UPLOAD + 1)
    if len(content) > MAX_UPLOAD:
        raise HTTPException(413, "Image exceeds the 5 MB upload limit.")
    try:
        return detector.decode_image(content)
    except (OSError, UnidentifiedImageError, ValueError, Image.DecompressionBombError) as error:
        raise HTTPException(422, "Upload a valid JPEG, PNG, or WebP image up to 20 megapixels.") from error


def image_digest(image):
    digest = sha256(f"{image.width}x{image.height}:".encode())
    digest.update(image.tobytes())
    return digest.hexdigest()


@router.post("/profiles", status_code=201)
def create_profile(data: ProfileRequest):
    name = data.name.strip()
    if not name:
        raise HTTPException(422, "Enter a display name.")
    profile_id = uuid4().hex
    token = token_urlsafe(32)
    with database() as db:
        db.execute("INSERT INTO profiles (id, name, token_hash) VALUES (?, ?, ?)",
                   (profile_id, name, sha256(token.encode()).hexdigest()))
        return {"token": token, "profile": profile_view(db, get_profile(db, profile_id), now().date())}


@router.get("/me")
def profile(profile_id: str = Depends(profile_for_token)):
    with database() as db:
        return profile_view(db, get_profile(db, profile_id), now().date())


@router.get("/scans")
def scan_history(profile_id: str = Depends(profile_for_token)):
    with database() as db:
        rows = db.execute(
            "SELECT * FROM scans WHERE profile_id = ? ORDER BY created_at DESC LIMIT 30",
            (profile_id,),
        )
        return [scan_view(row) for row in rows]


@router.post("/detect")
def detect_waste(file: UploadFile = File(...), profile_id: str = Depends(profile_for_token)):
    image = read_image(file)
    digest = image_digest(image)

    def find_previous(db):
        return db.execute(
            "SELECT * FROM scans WHERE profile_id = ? AND digest = ?", (profile_id, digest)
        ).fetchone()

    def response(db, row, duplicate):
        return {
            **scan_view(row),
            "status": "detected",
            "guidance": GUIDANCE[row["category"]],
            "duplicate": duplicate,
            "awarded_now": 0 if duplicate else row["base_points"] + row["streak_bonus"],
            "profile": profile_view(db, get_profile(db, profile_id), now().date()),
        }

    with database() as db:
        previous = find_previous(db)
        if previous:
            return response(db, previous, True)
    try:
        detections = detector.detect(image)
    except Exception as error:
        logger.exception("YOLO inference failed")
        raise HTTPException(503, "Detector unavailable. Check the model setup on the server.") from error
    if not detections:
        return {"status": "no_detection", "detections": [], "awarded_now": 0}

    category = detections[0]["category"]
    points = 5 if category in {"bottle", "paper"} else BASE_POINTS[category]
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        previous = find_previous(db)
        if previous:
            return response(db, previous, True)
        current = now()
        today = current.date()
        user = get_profile(db, profile_id)
        previous_day = date.fromisoformat(user["last_day"]) if user["last_day"] else None
        if previous_day == today:
            streak, bonus = user["streak"], 0
        else:
            streak = user["streak"] + 1 if previous_day == today - timedelta(days=1) else 1
            bonus = {7: 50, 30: 200}.get(streak, 0)
        scan_id = uuid4().hex
        db.execute(
            """INSERT INTO scans (id, profile_id, digest, category, detections, base_points,
               streak_bonus, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (scan_id, profile_id, digest, category, json.dumps(detections), points, bonus,
             current.isoformat()),
        )
        db.execute(
            """UPDATE profiles SET points = points + ?, streak = ?, last_day = ?,
               longest_streak = MAX(longest_streak, ?) WHERE id = ?""",
            (points + bonus, streak, today.isoformat(), streak, profile_id),
        )
        return response(db, get_scan(db, scan_id, profile_id), False)


@router.post("/scans/{scan_id}/proof")
def submit_proof(scan_id: str, file: UploadFile = File(...),
                 profile_id: str = Depends(profile_for_token)):
    image = read_image(file)
    digest = image_digest(image)
    image.thumbnail((1280, 1280))
    proof = BytesIO()
    image.save(proof, format="JPEG", quality=86)
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        row = get_scan(db, scan_id, profile_id)
        if row["digest"] == digest:
            raise HTTPException(422, "Upload a separate photo showing the disposal.")
        if row["proof_status"] in {"pending", "approved"}:
            raise HTTPException(409, "This scan already has submitted proof.")
        db.execute(
            """UPDATE scans SET proof = ?, proof_type = 'image/jpeg', proof_status = 'pending'
               WHERE id = ?""",
            (proof.getvalue(), scan_id),
        )
    return verify_saved_proof(scan_id, profile_id)


@router.post("/scans/{scan_id}/proof/verify")
def verify_pending_proof(scan_id: str, profile_id: str = Depends(profile_for_token)):
    return verify_saved_proof(scan_id, profile_id)


def verify_saved_proof(scan_id, profile_id):
    with database() as db:
        row = get_scan(db, scan_id, profile_id)
        if row["proof_status"] == "approved":
            return {**scan_view(row), "awarded_now": 0, "proof_message": "Already verified."}
        if row["proof_status"] != "pending" or not row["proof"]:
            raise HTTPException(409, "Upload a new disposal photo first.")
        proof, category = row["proof"], row["category"]

    try:
        verdict = proof_verifier.verify(detector.decode_image(proof), category)
    except Exception as error:
        logger.exception("Disposal proof inference failed")
        raise HTTPException(
            503, "Your photo is saved. The verification model is unavailable. Use Verify saved photo to retry."
        ) from error

    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        row = get_scan(db, scan_id, profile_id)
        if row["proof_status"] == "approved":
            return {**scan_view(row), "awarded_now": 0, "proof_message": "Already verified."}
        if row["proof_status"] != "pending" or proof != row["proof"]:
            raise HTTPException(409, "The saved photo changed. Refresh the page and try again.")

        approved, reason = verdict
        if approved and db.execute(
            "SELECT 1 FROM scans WHERE proof_status = 'approved' AND proof = ? AND id != ?",
            (proof, scan_id),
        ).fetchone():
            approved, reason = False, "This disposal photo has already been used for points."

        bonus = PROOF_BONUS if approved else 0
        db.execute(
            "UPDATE scans SET proof_status = ?, proof_bonus = ? WHERE id = ?",
            ("approved" if approved else "rejected", bonus, scan_id),
        )
        if bonus:
            db.execute("UPDATE profiles SET points = points + ? WHERE id = ?", (bonus, profile_id))
        result = scan_view(get_scan(db, scan_id, profile_id))
        return {**result, "awarded_now": bonus, "proof_message": reason}


@router.get("/leaderboard")
def leaderboard():
    with database() as db:
        return [dict(row) for row in db.execute(
            "SELECT name, points FROM profiles ORDER BY points DESC, name, id LIMIT 10"
        )]
