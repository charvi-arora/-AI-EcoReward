from fastapi import APIRouter
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from groq import Groq
from backend.config import GROQ_API_KEY
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "You are the EcoScan assistant for waste sorting and recycling. "
    "The legacy EcoScan classifier uses ResNet50 and has two categories, organic and recyclable. "
    "Answer in clear, concise English. Keep to waste sorting, disposal, recycling and the EcoScan app. "
    "If the question is outside that scope, say that you can help with waste sorting. "
    "Explain when local disposal rules vary and say when you are unsure. "
    "Do not invent model results, statistics or local rules."
)

class ChatRequest(BaseModel):
    message: str

@router.post("/chat")
def chat(request: ChatRequest):
    try:
        client = Groq(api_key=GROQ_API_KEY)

        def generate():
            stream = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": request.message}
                ],
                temperature=0.3,
                max_tokens=500,
                stream=True
            )
            for chunk in stream:
                content = chunk.choices[0].delta.content
                if content:
                    yield content

        return StreamingResponse(generate(), media_type="text/plain; charset=utf-8")

    except Exception as e:
        logger.error(f"Chat error: {type(e).__name__}: {str(e)}")
        return JSONResponse({"error": "The chat service could not answer the request."}, status_code=500)