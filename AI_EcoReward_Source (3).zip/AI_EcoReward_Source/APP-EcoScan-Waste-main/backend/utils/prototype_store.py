"""SQLite storage for prototype profiles, scans, proof, and points."""
import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import date
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, token_hash TEXT UNIQUE NOT NULL,
    points INTEGER NOT NULL DEFAULT 0, streak INTEGER NOT NULL DEFAULT 0,
    longest_streak INTEGER NOT NULL DEFAULT 0, last_day TEXT
);
CREATE TABLE IF NOT EXISTS scans (
    id TEXT PRIMARY KEY, profile_id TEXT NOT NULL REFERENCES profiles(id),
    digest TEXT NOT NULL, category TEXT NOT NULL, detections TEXT NOT NULL,
    base_points INTEGER NOT NULL, streak_bonus INTEGER NOT NULL,
    created_at TEXT NOT NULL, proof BLOB, proof_type TEXT,
    proof_status TEXT NOT NULL DEFAULT 'none', proof_bonus INTEGER NOT NULL DEFAULT 0,
    UNIQUE(profile_id, digest)
);
"""

LEVELS = [
    (1500, "Earth Guardian"), (700, "Eco Champion"), (300, "Eco Warrior"),
    (100, "Eco Helper"), (0, "Eco Beginner"),
]


@contextmanager
def database():
    default = Path(__file__).resolve().parents[2] / "uploads" / "ecoreward.sqlite3"
    path = Path(os.environ.get("ECOREWARD_DB", str(default)))
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=10)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        connection.executescript(SCHEMA)
        yield connection
        connection.commit()
    finally:
        connection.close()


def profile_view(db, profile, today):
    verified = {
        row["category"]: row["total"]
        for row in db.execute(
            """SELECT category, COUNT(*) AS total FROM scans
               WHERE profile_id = ? AND proof_status = 'approved' GROUP BY category""",
            (profile["id"],),
        )
    }
    badges = []
    count = sum(verified.values())
    if count:
        badges.append("Eco Beginner")
    if verified.get("plastic", 0) >= 50:
        badges.append("Plastic Master")
    if verified.get("e_waste", 0) >= 20:
        badges.append("E-Waste Hero")
    if profile["longest_streak"] >= 30:
        badges.append("Eco Warrior")
    if count >= 500:
        badges.append("Earth Protector")
    stale = profile["last_day"] and (today - date.fromisoformat(profile["last_day"])).days > 1
    return {
        "id": profile["id"],
        "name": profile["name"],
        "points": profile["points"],
        "streak": 0 if stale else profile["streak"],
        "level": next(label for minimum, label in LEVELS if profile["points"] >= minimum),
        "badges": badges,
        "verified_disposals": count,
    }


def scan_view(row):
    return {
        "scan_id": row["id"],
        "category": row["category"],
        "detections": json.loads(row["detections"]),
        "points_awarded": row["base_points"],
        "streak_bonus": row["streak_bonus"],
        "proof_status": row["proof_status"],
        "proof_bonus": row["proof_bonus"],
        "created_at": row["created_at"],
    }
