"""Lazy YOLO inference and image decoding for the prototype."""
import logging
import os
from functools import lru_cache
from io import BytesIO
from threading import Lock

from PIL import Image, ImageOps

logger = logging.getLogger(__name__)
inference_lock = Lock()

# COCO supplies a generic bottle label. Fine-tuned weights can supply material labels.
LABELS = {
    "bottle": "bottle",
    "plastic": "plastic",
    "plastic bottle": "plastic",
    "glass": "glass",
    "glass bottle": "glass",
    "metal": "metal",
    "metal can": "metal",
    "aluminum can": "metal",
    "paper": "paper",
    "cardboard": "paper",
    "organic": "organic",
    "battery": "battery",
    "e waste": "e_waste",
    "electronic waste": "e_waste",
}


def decode_image(content):
    with Image.open(BytesIO(content)) as original:
        if original.format not in {"JPEG", "PNG", "WEBP"}:
            raise ValueError("Upload a JPEG, PNG, or WebP image.")
        if original.width * original.height > 20_000_000:
            raise ValueError("Image resolution exceeds 20 megapixels.")
        return ImageOps.exif_transpose(original).convert("RGB")


@lru_cache(maxsize=1)
def load_detector(weights):
    from ultralytics import YOLO

    return YOLO(weights, task="detect")


def detect(image):
    weights = os.environ.get("ECOREWARD_MODEL", "yolo11n.pt")
    with inference_lock:
        model = load_detector(weights)
        detections = predict_supported(model, image)
        if detections:
            return detections

        # A small center crop can reduce the effect of background clutter.
        x, y = round(image.width * 0.08), round(image.height * 0.08)
        if x == y == 0:
            return []
        crop = image.crop((x, y, image.width - x, image.height - y))
        detections = predict_supported(model, crop, x, y)
        if detections:
            return detections

        # A smaller input can make the outline clearer when fine texture
        # and reflections dominate the full-resolution prediction.
        return predict_supported(model, image, image_size=320)


def predict_supported(model, image, left=0, top=0, *, image_size=640):
    result = model.predict(image, device="cpu", imgsz=image_size, conf=0.35, verbose=False)[0]
    detections = []
    for box in result.boxes:
        label = result.names[int(box.cls.item())]
        normalized = label.lower().replace("_", " ").replace("-", " ").strip()
        category = LABELS.get(normalized)
        if category:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            detections.append({
                "label": label,
                "category": category,
                "confidence": round(box.conf.item(), 4),
                "box": [round(x1 + left), round(y1 + top), round(x2 + left), round(y2 + top)],
            })

    return sorted(detections, key=lambda item: item["confidence"], reverse=True)
