"""Use model detections to check whether a disposal photo shows an item inside a bin."""
from functools import lru_cache
from pathlib import Path
from threading import Lock

MODEL = Path(__file__).resolve().parents[2] / "yolov8s-worldv2.pt"
EMBEDDINGS = Path(__file__).resolve().parents[1] / "assets" / "proof-label-embeddings.npz"
BIN_LABELS = {"trash bin", "recycling bin", "trash can", "wastebasket"}
ITEM_LABELS = {
    "bottle": {"bottle", "plastic bottle", "glass bottle"},
    "plastic": {"plastic bottle"},
    "glass": {"glass bottle"},
    "metal": {"drink can"},
    "paper": {"paper", "cardboard"},
    "battery": {"battery"},
    "e_waste": {"electronic waste"},
    "organic": {"food waste"},
}
inference_lock = Lock()


@lru_cache(maxsize=1)
def load_model():
    import numpy as np
    import torch
    from ultralytics import YOLOWorld

    if not MODEL.is_file():
        raise FileNotFoundError(MODEL)
    model = YOLOWorld(str(MODEL))
    # Fixed prompts encoded offline with the Ultralytics CLIP text encoder.
    # The app can use the embeddings without downloading a text encoder at runtime.
    with np.load(EMBEDDINGS, allow_pickle=False) as data:
        names = data["labels"].tolist()
        model.model.txt_feats = torch.from_numpy(data["features"])
    model.model.model[-1].nc = len(names)
    model.model.names = dict(enumerate(names))
    return model


def verify(image, category):
    item_labels = ITEM_LABELS.get(category, set())
    with inference_lock:
        result = load_model().predict(
            image, device="cpu", imgsz=640, conf=0.30, verbose=False
        )[0]

    items, bins = [], []
    for box in result.boxes:
        label = result.names[int(box.cls.item())]
        coords = box.xyxy[0].tolist()
        if label in item_labels:
            items.append(coords)
        elif label in BIN_LABELS:
            bins.append(coords)

    if not bins:
        return False, "AI could not identify a bin. Take a photo from above with the open bin visible."
    if not items:
        return False, "AI could not identify the scanned type of item. Keep it visible inside the bin."
    if any(item_inside_bin(item, container) for item in items for container in bins):
        return True, "AI verified the disposal photo. +20 EcoPoints."
    return False, "AI found the item and bin but could not see the item inside it. Show both from above."


def item_inside_bin(item, container):
    x1, y1, x2, y2 = item
    bx1, by1, bx2, by2 = container
    item_area = (x2 - x1) * (y2 - y1)
    bin_area = (bx2 - bx1) * (by2 - by1)
    overlap = max(0, min(x2, bx2) - max(x1, bx1)) * max(0, min(y2, by2) - max(y1, by1))
    return 0 < item_area <= 0.6 * bin_area and overlap >= 0.85 * item_area
