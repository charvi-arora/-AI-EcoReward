import os
import sys
from pathlib import Path

# Set parent directory in sys.path before local imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from backend.routes import classify, chat, prototype, rewards
import uvicorn
app = FastAPI()
frontend = Path(__file__).resolve().parents[1] / "frontend"
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8081", "http://127.0.0.1:8081"],
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)

app.mount("/static", StaticFiles(directory=frontend / "static"), name="static")

app.include_router(classify.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(rewards.router)
app.include_router(prototype.router)

@app.get("/", include_in_schema=False)
@app.get("/demo", include_in_schema=False)
def prototype_demo():
    return FileResponse(
        frontend / "templates" / "prototype.html",
        headers={"Cache-Control": "no-cache"},
    )

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
