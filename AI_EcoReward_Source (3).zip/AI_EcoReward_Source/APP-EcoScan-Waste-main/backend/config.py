import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
MODEL_PATH = "backend/models/resnet50_waste_compressed.pth"
UPLOAD_FOLDER = "uploads"

CLASS_DESCRIPTIONS = {
    "O": "Organic waste includes leftovers, fruit peels, vegetables and leaves. Follow your local composting or food-waste collection rules.",
    "R": "Recyclable waste can include paper, plastic, metal and glass. Check which items your local recycling service accepts."
}

CLASS_NAMES = {
    "O": "Organic waste",
    "R": "Recyclable waste"
}